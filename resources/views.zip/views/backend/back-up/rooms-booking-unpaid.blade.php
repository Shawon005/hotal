@extends('backend.layout.master')
@section('content')
        <div class="page-content page-content-white">
            
            <div class="container">        
                
                <div class="row">
                    <!-- Table -->
                    <div class="col-md-12">
                
                        <div class="block block-fill-white">
                            <div class="header">
                                <h2>Paid Room Bookings</h2>
                                <span class="pull-right"><a href="rooms-booking-unpaid-addbooking.html" type="button" class="btn btn-primary"><i class="icon-fixed-width icon-plus"></i>Add Booking</a> </span>                                       
                            </div>
                            <div class="content">

                                <table cellpadding="0" cellspacing="0" width="100%" class="table table-bordered table-striped sortable">
                                    <thead>
                                        <tr>
                                                                             
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>No Page Found</td>
                                        </tr>
                                                                        
                                    </tbody>
                                </table>                                        

                            </div>
                        </div>
                  
                    </div>


                </div>
                
            </div>            
            
        </div>
 @endsection